<?php
require_once("../Controller/Controller.php");
?>
<div id="entete">
	    <h1>Site d'actualité du MGLSI</h1>
	    <!-- <hr> -->
</div>